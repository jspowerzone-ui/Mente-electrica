// Obtener el nombre de la URL
const params = new URLSearchParams(window.location.search);
const nombre = params.get("nombre");

// Mostrarlo en el título
if(nombre){
    document.getElementById("titulo").innerText = "📬 Buzón de " + nombre;
}
