function enviar() {
    const de = document.getElementById("de").value.trim();
    const texto = document.getElementById("msg").value.trim();
    const tipo = document.getElementById("tipo").value;

    if (!de || !texto) {
        alert("Escribe tu nombre y el mensaje");
        return;
    }

    fetch("/MENTE_ELECTRICA/Backend/PHP/Mensajes.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            para: "Gabriela",  // buzón que recibe
            de: de,             // remitente
            texto: texto,
            tipo: tipo
        })
    })
    .then(res => res.text())
    .then(resp => console.log("Mensaje enviado:", resp))
    .catch(err => console.error("Error:", err));

    document.getElementById("de").value = "";
    document.getElementById("msg").value = "";
}