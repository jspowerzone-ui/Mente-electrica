const nombre = "Gabriela"; // buzón

function cargarMensajes() {
    fetch("/MENTE_ELECTRICA/Backend/PHP/Mensajes.php")
        .then(res => res.json())
        .then(data => {
            const gmail = document.getElementById("panel");
            const wsp = document.getElementById("panel-wsp");
            const otro = document.getElementById("panel-otro");

            gmail.innerHTML = "";
            wsp.innerHTML = "";
            otro.innerHTML = "";

            data.forEach(m => {
                if (m.para === nombre) {
                    const div = document.createElement("div");
                    div.className = "mensaje";
                    div.innerText = `${m.de}: ${m.texto}`; // Mostrar remitente

                    if (m.tipo === "gmail") gmail.appendChild(div);
                    else if (m.tipo === "whatsapp") wsp.appendChild(div);
                    else otro.appendChild(div);
                }
            });
        })
        .catch(err => console.error("Error cargando mensajes:", err));
}

setInterval(cargarMensajes, 2000);