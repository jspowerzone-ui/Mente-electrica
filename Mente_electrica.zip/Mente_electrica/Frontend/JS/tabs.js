function cambiar(panelID, boton) {
    // Ocultar todos los paneles
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('show'));

    // Quitar active de todos los botones
    document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));

    // Mostrar el panel seleccionado
    document.getElementById(panelID).classList.add('show');

    // Marcar botón como activo
    boton.classList.add('active');
}