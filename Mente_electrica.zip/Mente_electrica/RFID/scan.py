import serial
import webbrowser
import time

PUERTO = 'COM3'
BAUDIOS = 9600

ser = serial.Serial(PUERTO, BAUDIOS)
time.sleep(2)

print("📡 Escanea tarjeta...")

ultimo_uid = ""

while True:
    if ser.in_waiting > 0:

        # 🔥 LEER DESDE ARDUINO
        uid = ser.readline().decode()

        # 🔥 LIMPIEZA COMPLETA
        uid = uid.replace("UID:", "")   # quita "UID:"
        uid = uid.strip()               # quita saltos de línea
        uid = uid.replace(" ", "")      # quita espacios
        uid = uid.upper()               # MAYÚSCULAS

        # 🔥 EVITAR ERRORES
        if uid == "" or len(uid) < 4:
            continue

        if uid != ultimo_uid:
            ultimo_uid = uid

            print("💳 UID limpio:", uid)

            # ⚠️ CORREGIDO (sin espacios en URL)
            url = f"http://localhost/MENTE_ELECTRICA/Backend/PHP/scan.php?uid=CCAE1405"

            webbrowser.open(url)

            time.sleep(2)