<?php

$usuarios = [
    "CCAE1405" => "Gabriela",  // 👈 TU TARJETA
    "A1B2C3D4" => "Maria"
];

if(isset($_GET['uid'])){
    $uid = strtoupper(trim($_GET['uid']));

    if(array_key_exists($uid, $usuarios)){
        $nombre = $usuarios[$uid];
        header("Location: /MENTE_ELECTRICA/Frontend/HTML/buzon.html?nombre=" . $nombre);
        exit();
    } else {
        echo "❌ Tarjeta no registrada";
    }
}
?>