<?php
$archivo = '../JSON/Mensajes.json'; // Archivo donde se guardan los mensajes

// Leer la petición
$input = file_get_contents('php://input');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($input)) {
    $data = json_decode($input, true);

    if (!$data) {
        echo "Error: JSON inválido";
        exit;
    }

    // Leer mensajes existentes
    if(file_exists($archivo)) {
        $mensajes = json_decode(file_get_contents($archivo), true);
        if (!$mensajes) $mensajes = [];
    } else {
        $mensajes = [];
    }

    // Agregar mensaje nuevo
    $mensajes[] = $data;

    // Guardar en JSON
    if(file_put_contents($archivo, json_encode($mensajes, JSON_PRETTY_PRINT))) {
        echo "ok";
    } else {
        echo "Error al guardar JSON";
    }
    exit;
}

// GET → devolver todos los mensajes
$mensajes = file_exists($archivo) ? json_decode(file_get_contents($archivo), true) : [];
echo json_encode($mensajes, JSON_PRETTY_PRINT);
?>